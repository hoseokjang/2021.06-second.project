package kr.co.life;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.life.community.dao.CommunityDao;
import kr.co.life.community.dto.CommunityDto;

@Controller
public class HomeController {
	
	@Autowired
	public SqlSession sqlSession;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "/main";
	}
	@RequestMapping("/main")
	public String main(Model model)
	{
		// 공지사항 5개
		
		// 자유게시판 5개
		CommunityDao cdao = sqlSession.getMapper(CommunityDao.class);
		ArrayList<CommunityDto> clist = cdao.main_commu();
		model.addAttribute("clist", clist);
		// 레시피 공유 5개
		return "/main";
	}
	@RequestMapping("/introduce")
	public String introduce()
	{
		return "/intro/introduce";
	}
	@RequestMapping("/useway")
	public String useway()
	{
		return "/intro/useway";
	}
}
